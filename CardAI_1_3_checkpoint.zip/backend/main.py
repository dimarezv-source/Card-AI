from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, Request, HTTPException

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "data" / "uploads"
UPLOADS.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="CardAI API", version="1.3")


@app.get("/api/health")
def health():
    return {"ok": True, "app": "CardAI", "version": "1.3", "timer_enabled": False, "avito_autopublish": False}


@app.post("/api/projects/{project_id}/photos")
async def upload_photo(project_id: str, request: Request):
    content_type = request.headers.get("content-type", "image/jpeg").split(";")[0].strip().lower()
    allowed = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
    suffix = allowed.get(content_type)
    if not suffix:
        raise HTTPException(415, "Unsupported image content type")
    data = await request.body()
    if not data:
        raise HTTPException(400, "Empty image")
    if len(data) > 20 * 1024 * 1024:
        raise HTTPException(413, "File is larger than 20 MB")
    item_id = uuid4().hex[:12]
    target = UPLOADS / f"{project_id}_{item_id}{suffix}"
    target.write_bytes(data)
    return {"ok": True, "project_id": project_id, "item_id": item_id, "file": target.name, "next_step": "analyze"}


@app.post("/api/projects/{project_id}/analyze")
def analyze(project_id: str):
    photos = list(UPLOADS.glob(f"{project_id}_*"))
    return {
        "ok": True,
        "project_id": project_id,
        "status": "ready_for_ai" if photos else "no_photos",
        "photo_count": len(photos),
        "fields": [],
        "confidence": {},
        "needs_user_review": True,
    }


@app.post("/api/projects/{project_id}/listing-draft")
def listing_draft(project_id: str):
    photos = list(UPLOADS.glob(f"{project_id}_*"))
    return {
        "ok": True,
        "project_id": project_id,
        "marketplace": "avito",
        "photo_count": len(photos),
        "title": "",
        "description": "",
        "characteristics": {},
        "needs_user_review": True,
        "automatic_publish": False,
        "status": "waiting_for_ai",
    }
