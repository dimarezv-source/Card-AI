# CardAI backend

Минимальный API-слой для Android-клиента.

Запуск:
`python -m uvicorn main:app --host 0.0.0.0 --port 8000`

Проверка:
`GET /api/health`

Фото:
`POST /api/projects/{project_id}/photos`
Тело запроса — бинарное изображение.

Анализ:
`POST /api/projects/{project_id}/analyze`

Черновик:
`POST /api/projects/{project_id}/listing-draft`

AI-слой намеренно не имитируется: без реального подключённого AI он возвращает безопасный результат, требующий дальнейшей обработки.
