package com.cardai.app

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private enum class Screen(val title: String) { PROJECT("Товар"), DRAFT("Объявление"), EXPORT("Готово") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { CardAiApp() } }
}

@Composable
private fun CardAiApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.PROJECT) }
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var projectId by remember { mutableStateOf("demo") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf(ListingDraft()) }

    val picker = rememberLauncherForActivityResult(PickMultipleVisualMedia(maxItems = 20)) { selected ->
        photos = selected
        message = if (selected.isEmpty()) "Фото не выбраны" else "Выбрано фото: ${selected.size}"
    }

    fun startAnalysis() {
        if (photos.isEmpty() || busy) return
        scope.launch {
            busy = true
            val uploadResults = photos.map { CardAiApi.uploadPhoto(context, projectId, it) }
            val uploaded = uploadResults.count { it.ok }
            if (uploaded == 0) { message = "Не удалось загрузить фотографии"; busy = false; return@launch }
            val analysis = CardAiApi.analyze(projectId)
            val draftResult = CardAiApi.listingDraft(projectId)
            draft = draftResult.second
            message = if (analysis.ok && draftResult.first.ok) "Черновик подготовлен — проверь его перед экспортом" else "Фото загружены, но анализ пока не завершён"
            busy = false
            screen = Screen.DRAFT
        }
    }

    MaterialTheme {
        Scaffold(bottomBar = { NavigationBar { Screen.entries.forEach { item ->
            NavigationBarItem(selected = screen == item, onClick = { screen = item }, icon = {}, label = { Text(item.title) })
        } } }) { padding ->
            Surface(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    Screen.PROJECT -> ProjectScreen(photos, message, busy, picker, { startAnalysis() })
                    Screen.DRAFT -> DraftScreen(photos.size, draft, message) { screen = Screen.EXPORT }
                    Screen.EXPORT -> ExportScreen(draft)
                }
            }
        }
    }
}

@Composable
private fun ProjectScreen(photos: List<Uri>, message: String, busy: Boolean, picker: androidx.activity.result.ActivityResultLauncher<PickVisualMediaRequest>, onAnalyze: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("CardAI", style = MaterialTheme.typography.labelLarge)
        Text("Продай вещь проще", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Добавь фотографии — CardAI подготовит основу объявления, а ты всё проверишь.")
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Шаг 1 · Фотографии", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { picker.launch(PickVisualMediaRequest(PickMultipleVisualMedia.ImageOnly)) }, Modifier.fillMaxWidth()) { Text("Выбрать фотографии") }
            if (photos.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(photos) { uri ->
                    val bitmap = remember(uri) { BitmapFactory.decodeStream(context.contentResolver.openInputStream(uri)) }
                    bitmap?.let { Image(it.asImageBitmap(), null, Modifier.size(86.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop) }
                } }
                Text("Выбрано: ${photos.size} из 20")
                Button(onClick = onAnalyze, enabled = !busy, Modifier.fillMaxWidth()) { Text(if (busy) "Готовлю…" else "Анализировать товар") }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) {
            Text("Правило CardAI", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("Мы не должны выдумывать характеристики или состояние вещи. Сомнительные поля помечаются для проверки.")
        } }
    }
}

@Composable
private fun DraftScreen(photoCount: Int, draft: ListingDraft, message: String, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Проверка объявления", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(message)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Фото: $photoCount")
            Text("Заголовок", style = MaterialTheme.typography.titleMedium)
            Text(if (draft.title.isBlank()) "Пока не определён" else draft.title)
            Text("Описание", style = MaterialTheme.typography.titleMedium)
            Text(if (draft.description.isBlank()) "Пока не определено" else draft.description)
            Text("Характеристики", style = MaterialTheme.typography.titleMedium)
            if (draft.characteristics.isEmpty()) Text("Нет подтверждённых характеристик")
            else draft.characteristics.forEach { (k, v) -> Text("$k: $v") }
            if (draft.needsReview) Text("Перед экспортом проверь данные.", color = MaterialTheme.colorScheme.primary)
            Button(onClick = onNext, Modifier.fillMaxWidth()) { Text("Перейти к готовому") }
        } }
    }
}

@Composable
private fun ExportScreen(draft: ListingDraft) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Готово", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Экспорт для Avito")
            Text(if (draft.title.isBlank()) "Черновик ещё не содержит подтверждённых данных." else draft.title)
            Text("Публикация остаётся ручной — без автопубликации.")
        } }
    }
}
