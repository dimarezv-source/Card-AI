# CardAI release rules.
