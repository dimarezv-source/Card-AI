import json
import os
import unittest
from unittest.mock import patch

from fastapi.testclient import TestClient

import main


class FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        content = {
            "item_type": "керамическая кружка",
            "title": "Керамическая кружка",
            "description": "Кружка с ручкой, видимая на фотографии.",
            "characteristics": {"Тип": "кружка", "Материал": "керамика"},
            "confidence": {"Тип": 0.94},
            "needs_confirmation": ["Объём не подтверждён по фото."],
        }
        return json.dumps({
            "choices": [{"message": {"content": json.dumps(content, ensure_ascii=False)}}]
        }).encode("utf-8")


class CardAiApiTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(main.app)
        self.project_id = "unittest_cardai"
        self.old_key = os.environ.get("OPENAI_API_KEY")
        os.environ.pop("OPENAI_API_KEY", None)
        self.cleanup()

    def tearDown(self):
        self.cleanup()
        if self.old_key is None:
            os.environ.pop("OPENAI_API_KEY", None)
        else:
            os.environ["OPENAI_API_KEY"] = self.old_key

    def cleanup(self):
        for path in main.UPLOADS.glob(f"{self.project_id}_*"):
            path.unlink(missing_ok=True)
        main._result_path(self.project_id).unlink(missing_ok=True)

    def upload(self):
        return self.client.post(
            f"/api/projects/{self.project_id}/photos",
            content=b"test image bytes",
            headers={"content-type": "image/png"},
        )

    def test_health_reports_version_and_no_ai_key(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["version"], "1.4")
        self.assertFalse(response.json()["ai_configured"])

    def test_upload_rejects_unsupported_mime(self):
        response = self.client.post(
            f"/api/projects/{self.project_id}/photos",
            content=b"image",
            headers={"content-type": "image/heic"},
        )
        self.assertEqual(response.status_code, 415)

    def test_upload_rejects_oversize_content_length(self):
        response = self.client.post(
            f"/api/projects/{self.project_id}/photos",
            content=b"x",
            headers={
                "content-type": "image/png",
                "content-length": str(main.MAX_IMAGE_BYTES + 1),
            },
        )
        self.assertEqual(response.status_code, 413)

    def test_invalid_project_id_rejected(self):
        response = self.client.post("/api/projects/../bad/analyze")
        self.assertIn(response.status_code, (400, 404, 422))

    def test_missing_ai_key_is_honest(self):
        self.upload()
        response = self.client.post(f"/api/projects/{self.project_id}/analyze")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "waiting_for_ai")

        draft = self.client.post(f"/api/projects/{self.project_id}/listing-draft")
        self.assertEqual(draft.status_code, 200)
        self.assertEqual(draft.json()["title"], "")
        self.assertEqual(draft.json()["status"], "waiting_for_ai")

    def test_mock_vision_result_is_saved_for_draft(self):
        self.upload()
        os.environ["OPENAI_API_KEY"] = "unit-test-key"
        with patch("main.urllib.request.urlopen", return_value=FakeResponse()):
            response = self.client.post(f"/api/projects/{self.project_id}/analyze")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["status"], "ready_for_review")
        self.assertEqual(response.json()["fields"]["Материал"], "керамика")

        draft = self.client.post(f"/api/projects/{self.project_id}/listing-draft")
        body = draft.json()
        self.assertEqual(body["title"], "Керамическая кружка")
        self.assertIn("Объём не подтверждён по фото.", body["needs_confirmation"])
        self.assertTrue(body["needs_user_review"])
        self.assertFalse(body["automatic_publish"])

    def test_new_photo_invalidates_old_analysis(self):
        self.upload()
        os.environ["OPENAI_API_KEY"] = "unit-test-key"
        with patch("main.urllib.request.urlopen", return_value=FakeResponse()):
            self.client.post(f"/api/projects/{self.project_id}/analyze")
        self.assertIsNotNone(main._load_result(self.project_id))
        self.upload()
        self.assertIsNone(main._load_result(self.project_id))


if __name__ == "__main__":
    unittest.main()
