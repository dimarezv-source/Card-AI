# CardAI backend 1.4

Backend для Android-клиента CardAI. AI-анализ фотографий выполняется через OpenAI-совместимый Chat Completions API с поддержкой изображений.

## Запуск

Python 3.10+:
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Задайте ключ **на сервере**, не в Android-приложении:
```bash
# Windows PowerShell
$env:OPENAI_API_KEY="ваш_ключ"
$env:CARDAI_AI_MODEL="gpt-4o-mini"
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Для Linux/macOS используйте `export OPENAI_API_KEY="..."`.
Можно переопределить `CARDAI_AI_MODEL`, `OPENAI_API_BASE_URL` и `CARDAI_AI_TIMEOUT_SECONDS`.

Проверка: `GET /api/health`. Поле `ai_configured` показывает только наличие настройки ключа, но не проверяет его действительность.

## API
- `POST /api/projects/{project_id}/photos` — тело запроса: бинарное JPEG/PNG/WebP изображение, до 20 MiB.
- `POST /api/projects/{project_id}/analyze` — анализ первых четырёх изображений с помощью vision-модели.
- `POST /api/projects/{project_id}/listing-draft` — возвращает сохранённый результат анализа.

Результат требует ручной проверки. Модель инструктируется не выдумывать неизвестные характеристики; поля с сомнениями передаются в `needs_confirmation`. Это снижает риск ошибок, но не гарантирует абсолютную точность.

Если `OPENAI_API_KEY` не задан, API честно возвращает `waiting_for_ai`. Ключ не должен попадать в APK, репозиторий или клиентские логи. В продакшене дополнительно настройте HTTPS, авторизацию, лимиты запросов, очистку загруженных фотографий и мониторинг затрат.

## Docker

From this directory, set `OPENAI_API_KEY` in the shell / deployment secrets, then run:
```bash
docker compose up --build -d
```
Do not put a real key in `.env.example`, Android code, or a committed file. The Compose configuration persists uploads/results in a named volume.

## Automated tests

```bash
pip install -r requirements-dev.txt
python -m unittest discover -s tests -v
```
The vision integration test uses a mocked provider response; it does not consume API credits or verify that a real API key/model is enabled.
