import base64
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, Request, HTTPException

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "data" / "uploads"
RESULTS = BASE / "data" / "results"
UPLOADS.mkdir(parents=True, exist_ok=True)
RESULTS.mkdir(parents=True, exist_ok=True)

APP_VERSION = "1.4"
MAX_IMAGE_BYTES = 20 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}

app = FastAPI(title="CardAI API", version=APP_VERSION)


def _safe_project_id(project_id: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", project_id):
        raise HTTPException(400, "Invalid project ID")
    return project_id


def _project_photos(project_id: str) -> list[Path]:
    project_id = _safe_project_id(project_id)
    return sorted(UPLOADS.glob(f"{project_id}_*"))


def _result_path(project_id: str) -> Path:
    return RESULTS / f"{_safe_project_id(project_id)}.json"


def _load_result(project_id: str) -> dict | None:
    path = _result_path(project_id)
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except (OSError, json.JSONDecodeError):
        return None


def _save_result(project_id: str, result: dict) -> None:
    _result_path(project_id).write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _ai_configured() -> bool:
    return bool(os.getenv("OPENAI_API_KEY", "").strip())


def _call_vision_model(photos: list[Path]) -> dict:
    """Call a vision-capable Chat Completions model; never fabricate absent facts."""
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("AI_NOT_CONFIGURED")

    model = os.getenv("CARDAI_AI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"
    api_base = os.getenv("OPENAI_API_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    image_items = []
    # Limit payload size and latency; use the first four photos in stable order.
    for path in photos[:4]:
        mime = {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}.get(path.suffix.lower())
        if not mime:
            continue
        raw = path.read_bytes()
        if not raw or len(raw) > MAX_IMAGE_BYTES:
            continue
        encoded = base64.b64encode(raw).decode("ascii")
        image_items.append({
            "type": "image_url",
            "image_url": {"url": f"data:{mime};base64,{encoded}", "detail": "high"},
        })

    if not image_items:
        raise RuntimeError("NO_VALID_IMAGES")

    system_prompt = (
        "Ты — осторожный помощник по созданию объявлений для Avito. "
        "Осматривай только то, что действительно видно на фотографиях. "
        "Не угадывай бренд, модель, размер, материал, год, комплектность, работоспособность "
        "или состояние, если это нельзя уверенно подтвердить визуально. "
        "Не выдавай предположения за факты. Не добавляй цену. "
        "Если значение неизвестно, опусти поле. Все сомнительные детали перечисли в needs_confirmation. "
        "Верни только JSON-объект с ключами: item_type (string), title (string), "
        "description (string), characteristics (object со строковыми значениями), "
        "confidence (object с числами от 0 до 1), needs_confirmation (array строк). "
        "Заголовок краткий и нейтральный. Описание сообщает только видимые/подтверждённые сведения "
        "и не обещает неустановленных свойств. Пиши по-русски."
    )
    user_content = [{
        "type": "text",
        "text": (
            "Определи, какой товар можно осторожно описать по этим фото. "
            "Если тип товара неясен, прямо укажи это и не придумывай характеристики."
        ),
    }, *image_items]
    payload = {
        "model": model,
        "temperature": 0.1,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
    }
    request = urllib.request.Request(
        f"{api_base}/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    timeout = float(os.getenv("CARDAI_AI_TIMEOUT_SECONDS", "90"))
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response_body = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        # Do not include request headers or API keys in logs/messages.
        detail = exc.read(1000).decode("utf-8", errors="replace")
        raise RuntimeError(f"AI_PROVIDER_ERROR_{exc.code}: {detail}") from None
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise RuntimeError(f"AI_CONNECTION_ERROR: {type(exc).__name__}") from None

    try:
        content = response_body["choices"][0]["message"]["content"]
        parsed = json.loads(content)
    except (KeyError, IndexError, TypeError, json.JSONDecodeError):
        raise RuntimeError("AI_INVALID_RESPONSE") from None

    if not isinstance(parsed, dict):
        raise RuntimeError("AI_INVALID_RESPONSE")
    # Normalize the provider output into a safe, predictable API shape.
    title = parsed.get("title") if isinstance(parsed.get("title"), str) else ""
    description = parsed.get("description") if isinstance(parsed.get("description"), str) else ""
    chars = parsed.get("characteristics") if isinstance(parsed.get("characteristics"), dict) else {}
    confidence = parsed.get("confidence") if isinstance(parsed.get("confidence"), dict) else {}
    needs = parsed.get("needs_confirmation") if isinstance(parsed.get("needs_confirmation"), list) else []
    return {
        "item_type": parsed.get("item_type", "") if isinstance(parsed.get("item_type", ""), str) else "",
        "title": title[:160],
        "description": description[:6000],
        "characteristics": {
            str(k)[:80]: str(v)[:300]
            for k, v in chars.items()
            if isinstance(k, str) and isinstance(v, (str, int, float)) and str(v).strip()
        },
        "confidence": {
            str(k)[:80]: max(0.0, min(1.0, float(v)))
            for k, v in confidence.items()
            if isinstance(k, str) and isinstance(v, (int, float))
        },
        "needs_confirmation": [str(x)[:300] for x in needs if isinstance(x, str)][:30],
        "needs_user_review": True,
        "status": "ready_for_review",
    }


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "app": "CardAI",
        "version": APP_VERSION,
        "ai_configured": _ai_configured(),
        "timer_enabled": False,
        "avito_autopublish": False,
    }


@app.post("/api/projects/{project_id}/photos")
async def upload_photo(project_id: str, request: Request):
    project_id = _safe_project_id(project_id)
    content_type = request.headers.get("content-type", "image/jpeg").split(";")[0].strip().lower()
    suffix = ALLOWED_TYPES.get(content_type)
    if not suffix:
        raise HTTPException(415, "Unsupported image content type")
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > MAX_IMAGE_BYTES:
                raise HTTPException(413, "File is larger than 20 MB")
        except ValueError:
            raise HTTPException(400, "Invalid Content-Length")
    data = await request.body()
    if not data:
        raise HTTPException(400, "Empty image")
    if len(data) > MAX_IMAGE_BYTES:
        raise HTTPException(413, "File is larger than 20 MB")
    target = UPLOADS / f"{project_id}_{uuid4().hex[:12]}{suffix}"
    target.write_bytes(data)
    # Any new image invalidates the previous draft for this project.
    _result_path(project_id).unlink(missing_ok=True)
    return {
        "ok": True,
        "project_id": project_id,
        "item_id": target.stem.removeprefix(f"{project_id}_"),
        "file": target.name,
        "next_step": "analyze",
    }


@app.post("/api/projects/{project_id}/analyze")
def analyze(project_id: str):
    project_id = _safe_project_id(project_id)
    photos = _project_photos(project_id)
    if not photos:
        return {
            "ok": True, "project_id": project_id, "status": "no_photos",
            "photo_count": 0, "fields": [], "confidence": {}, "needs_user_review": True,
        }
    if not _ai_configured():
        return {
            "ok": True, "project_id": project_id, "status": "waiting_for_ai",
            "photo_count": len(photos), "fields": [], "confidence": {},
            "needs_user_review": True,
            "message": "AI не подключён: задайте OPENAI_API_KEY на сервере.",
        }
    try:
        result = _call_vision_model(photos)
    except RuntimeError as exc:
        reason = str(exc)
        status = "waiting_for_ai" if reason == "AI_NOT_CONFIGURED" else "ai_error"
        return {
            "ok": False, "project_id": project_id, "status": status,
            "photo_count": len(photos), "fields": [], "confidence": {},
            "needs_user_review": True, "message": reason[:240],
        }
    _save_result(project_id, result)
    return {
        "ok": True,
        "project_id": project_id,
        "status": result["status"],
        "photo_count": len(photos),
        "item_type": result["item_type"],
        "fields": result["characteristics"],
        "confidence": result["confidence"],
        "needs_confirmation": result["needs_confirmation"],
        "needs_user_review": True,
    }


@app.post("/api/projects/{project_id}/listing-draft")
def listing_draft(project_id: str):
    project_id = _safe_project_id(project_id)
    photos = _project_photos(project_id)
    result = _load_result(project_id)
    if not photos:
        status = "no_photos"
    elif result:
        status = result.get("status", "ready_for_review")
    elif not _ai_configured():
        status = "waiting_for_ai"
    else:
        status = "analysis_required"
    if not result:
        result = {}
    return {
        "ok": True,
        "project_id": project_id,
        "marketplace": "avito",
        "photo_count": len(photos),
        "title": result.get("title", ""),
        "description": result.get("description", ""),
        "characteristics": result.get("characteristics", {}),
        "confidence": result.get("confidence", {}),
        "needs_confirmation": result.get("needs_confirmation", []),
        "needs_user_review": True,
        "automatic_publish": False,
        "status": status,
    }
