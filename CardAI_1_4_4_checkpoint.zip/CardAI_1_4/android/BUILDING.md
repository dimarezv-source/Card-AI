# CardAI Android build notes

## Prerequisites
- Android Studio with an Android SDK matching `compileSdk` in `app/build.gradle.kts`.
- A compatible JDK (use the JDK bundled with Android Studio if unsure).
- A Gradle installation or a complete Gradle Wrapper (`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar`). The checkpoint currently does **not** include the wrapper script/JAR.

Run `../scripts/check_android_build_env.sh` from this directory (or any directory) to check local prerequisites. This is a diagnostic only, not an APK build.

## Debug build
Open the `android/` directory in Android Studio, let Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The debug variant points to `http://10.0.2.2:8000`, the host machine's port 8000 from the Android emulator. A debug-only manifest allows cleartext HTTP for this local development endpoint. Do not use the debug HTTP setup for production.

## Release backend URL
Set a real HTTPS API base URL with a Gradle property, for example in your local `~/.gradle/gradle.properties`:
```properties
CARDAI_API_BASE_URL=https://your-real-api-domain.example
```
Use the actual backend domain you control. Do not commit credentials. The release build default intentionally remains a placeholder until a production URL is configured.

## Backend tests
From the repository root run:
```sh
./scripts/verify_backend.sh
```
The tests mock the vision provider; they do not make a real AI request and do not verify deployment connectivity.

## Current limitation
No successful APK build has been verified yet. Backend tests passing does not imply the Android app compiles or runs on a device.

## Hosted build (GitHub Actions)
The repository includes `.github/workflows/android-build.yml`. After pushing the source to GitHub, open **Actions → Android debug APK**. The workflow installs Java 21, Android SDK platform 37 and Gradle 9.6.0, runs `assembleDebug`, and uploads `CardAI-debug-apk` when successful. This workflow has been added to the source but must run on GitHub before an APK build can be considered verified.
