package com.cardai.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val CONNECT_TIMEOUT = 10_000
private const val READ_TIMEOUT = 30_000

data class ApiResult(val ok: Boolean, val message: String, val body: JSONObject? = null)

data class ListingDraft(
    val title: String = "",
    val description: String = "",
    val characteristics: Map<String, String> = emptyMap(),
    val needsConfirmation: List<String> = emptyList(),
    val needsReview: Boolean = true
)

object CardAiApi {
    suspend fun uploadPhoto(context: Context, projectId: String, uri: Uri): ApiResult = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext ApiResult(false, "Не удалось прочитать фото")
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            val connection = open("/api/projects/$projectId/photos", "POST").apply {
                doOutput = true
                setRequestProperty("Content-Type", mime)
                setRequestProperty("X-Filename", uri.lastPathSegment ?: "photo.jpg")
            }
            connection.outputStream.use { it.write(bytes) }
            readResult(connection, "Фото загружено")
        }.getOrElse { ApiResult(false, "Не удалось загрузить фото: ${it.message ?: "ошибка"}") }
    }

    suspend fun analyze(projectId: String): ApiResult = withContext(Dispatchers.IO) {
        runCatching { readResult(open("/api/projects/$projectId/analyze", "POST"), "Анализ готов") }
            .getOrElse { ApiResult(false, "Не удалось запустить анализ") }
    }

    suspend fun listingDraft(projectId: String): Pair<ApiResult, ListingDraft> = withContext(Dispatchers.IO) {
        runCatching {
            val result = readResult(open("/api/projects/$projectId/listing-draft", "POST"), "Черновик готов")
            val body = result.body ?: JSONObject()
            val chars = mutableMapOf<String, String>()
            val jsonChars = body.optJSONObject("characteristics")
            jsonChars?.keys()?.forEach { key -> chars[key] = jsonChars.optString(key) }
            val confirmation = mutableListOf<String>()
            val jsonConfirmation = body.optJSONArray("needs_confirmation")
            if (jsonConfirmation != null) {
                for (index in 0 until jsonConfirmation.length()) {
                    val value = jsonConfirmation.optString(index).trim()
                    if (value.isNotEmpty()) confirmation += value
                }
            }
            result to ListingDraft(
                title = body.optString("title"),
                description = body.optString("description"),
                characteristics = chars,
                needsConfirmation = confirmation,
                needsReview = body.optBoolean("needs_user_review", true)
            )
        }.getOrElse { ApiResult(false, "Не удалось получить черновик") to ListingDraft() }
    }

    private fun open(path: String, method: String): HttpURLConnection =
        (URL("${BuildConfig.CARDAI_API_BASE_URL}$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = CONNECT_TIMEOUT
            readTimeout = READ_TIMEOUT
            setRequestProperty("Accept", "application/json")
        }

    private fun readResult(connection: HttpURLConnection, successMessage: String): ApiResult {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        val body = runCatching { JSONObject(text) }.getOrNull()
        return if (code in 200..299) ApiResult(true, successMessage, body)
        else ApiResult(false, "Сервер вернул ошибку $code", body)
    }
}
