# CardAI 1.4.3 — Android build preparation checkpoint

## Purpose
This checkpoint prioritizes getting the first reproducible Android debug APK. It adds a GitHub Actions workflow so the project can be built in a clean hosted Linux environment even when the local workspace lacks Android SDK and Gradle.

## Changes
- Added `.github/workflows/android-build.yml`.
- Workflow provisions Java 21, Android SDK platform 37/build-tools, Gradle 9.6.0.
- Workflow runs `gradle -p android --no-daemon assembleDebug` and uploads `app-debug.apk` as a 14-day artifact.
- Workflow supports pushes to `main`/`master`, pull requests, and manual `workflow_dispatch` runs.

## Verified in this workspace
- CardAI 1.4.2 archive was present and readable before this checkpoint.
- Backend automated tests: 7 passed in the prior checkpoint run; these use a mocked AI provider.
- Python syntax check passed in the prior checkpoint run.
- Android environment diagnostic found Java, but no Gradle, Android SDK, `adb`, `android/gradlew`, or `gradle-wrapper.jar`.
- Workflow file and required Android source/build files are included in this archive.

## Not yet verified
- This workspace cannot run the Android Gradle build because the local Android SDK and Gradle are absent.
- The new GitHub Actions workflow has not run on GitHub in this checkpoint. An APK is not included; it will only be produced if the workflow succeeds in the repository.
- No real OpenAI API request or device test was performed.

## How to get the APK
1. Push this checkpoint's source to the GitHub repository default branch (or create a branch/PR).
2. Open the repository's **Actions** tab and select **Android debug APK**.
3. Start **Run workflow** if needed, or wait for the push/PR workflow.
4. If the run succeeds, download the `CardAI-debug-apk` artifact from the run summary.

## Important caveats
- The debug build uses `http://10.0.2.2:8000`, suitable for an Android emulator talking to a backend on the host machine. A physical phone needs a reachable LAN/HTTPS URL configured appropriately.
- Release API URL remains a placeholder until a real HTTPS backend URL is supplied.
- If Android Gradle Plugin, Kotlin, Compose BOM, or SDK versions fail resolution, use the GitHub Actions log to pin mutually compatible versions in a follow-up checkpoint.
