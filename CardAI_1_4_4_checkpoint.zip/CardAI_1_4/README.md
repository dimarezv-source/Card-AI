# CardAI

Android-приложение для подготовки черновика объявления Avito по фотографиям товара. Пользователь проверяет результат; автопубликация и таймер отключены.

## Структура
- `android/` — Android-клиент на Kotlin/Jetpack Compose.
- `backend/` — API на FastAPI, интеграция с OpenAI-compatible vision API.
- `scripts/verify_backend.sh` — тесты backend.
- `scripts/check_android_build_env.sh` — проверка локальных Android build prerequisites.

## Быстрая проверка
```sh
./scripts/verify_backend.sh
./scripts/check_android_build_env.sh
```

Для настройки и сборки Android см. [`android/BUILDING.md`](android/BUILDING.md). Не добавляйте API-ключи в приложение или репозиторий; задавайте `OPENAI_API_KEY` на сервере.
