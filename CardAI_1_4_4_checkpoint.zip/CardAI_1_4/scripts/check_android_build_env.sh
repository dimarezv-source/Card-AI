#!/usr/bin/env sh
set -u
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
ANDROID="$ROOT/android"
missing=0
check_cmd() {
  if command -v "$1" >/dev/null 2>&1; then
    printf 'OK      %s: %s\n' "$1" "$(command -v "$1")"
  else
    printf 'MISSING %s\n' "$1"
    missing=1
  fi
}
check_cmd java
check_cmd adb
check_cmd gradle
if [ -f "$ANDROID/gradlew" ]; then
  printf 'OK      Gradle wrapper script exists\n'
else
  printf 'MISSING android/gradlew (wrapper script)\n'
  missing=1
fi
if [ -f "$ANDROID/gradle/wrapper/gradle-wrapper.jar" ]; then
  printf 'OK      Gradle wrapper JAR exists\n'
else
  printf 'MISSING android/gradle/wrapper/gradle-wrapper.jar\n'
  missing=1
fi
if [ -n "${ANDROID_HOME:-}" ] && [ -d "$ANDROID_HOME" ]; then
  printf 'OK      ANDROID_HOME=%s\n' "$ANDROID_HOME"
elif [ -n "${ANDROID_SDK_ROOT:-}" ] && [ -d "$ANDROID_SDK_ROOT" ]; then
  printf 'OK      ANDROID_SDK_ROOT=%s\n' "$ANDROID_SDK_ROOT"
else
  printf 'MISSING Android SDK (set ANDROID_HOME or ANDROID_SDK_ROOT)\n'
  missing=1
fi
if [ "$missing" -eq 0 ]; then
  printf '\nEnvironment looks ready for a build attempt; this script does not itself build the APK.\n'
else
  printf '\nAndroid build prerequisites are incomplete. See android/BUILDING.md.\n'
fi
exit "$missing"
