#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT/backend"
python -m compileall -q main.py tests
python -m unittest discover -s tests -v
